# THIS PROJECT IS NO LONGER BEING MAINTAINED 

* * *

# a1ive's GRUB 2

![](https://img.shields.io/github/license/a1ive/grub) ![](https://img.shields.io/travis/a1ive/grub) ![](https://img.shields.io/github/release-date/a1ive/grub) ![](https://img.shields.io/github/downloads/a1ive/grub/total)

Fork of GRUB 2 to add various features.

See the file INSTALL for instructions on how to build and install the GRUB 2 data and program files.

~~Extra modules: https://github.com/a1ive/grub-extras~~

Download: https://github.com/a1ive/grub/releases
若下载速度慢，建议使用 [gitd.cc](http://gitd.cc/) 下载

Manual: [简体中文](https://a1ive.github.io/grub2_zh.html)
