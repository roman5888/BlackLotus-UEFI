#define GRUB_TARGET_WORDSIZE 64
#define XX		64
#define ehdrXX ehdr64
#define grub_file_check_netbsdXX grub_file_check_netbsd64
#include "fileXX.c"
