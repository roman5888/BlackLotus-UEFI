#define MODE_BIGENDIAN 1
#include "mdraid_linux.c"
